﻿function createPrompt()
{
let lang=$('input[name="lang"]:checked').val();
let tone=$('input[name="tone"]:checked').val();

 var uMsg = $('#txtMsg').val() + ". Reply in " + lang + ". Tone of reply should be  " + tone;
if (!$('#frm')[0].checkValidity()) {
    $('#frm')[0].reportValidity();
}
else {
    message = $("#txtMsg").val();
    if ($.trim(message) == '') {
        return false;
    }
    // $('.message-input input').val(null);
    $('#Ask').html("<i class='fas fa-circle-notch fa-spin'></i>");
    $('#Ask').prop('disabled', true);
    $('#mssg').append("<div class='direct-chat-msg right'><div class='direct-chat-infos clearfix'><span class='direct-chat-name float-right'>Você</span></div><img class='direct-chat-img' src='img/user1-128x128.jpg' alt='Message User Image'> <div class='direct-chat-text'>" + message + "</div></div>");
    //scroll to question
    $('#mssg').stop().animate({
        scrollTop: $('#mssg')[0].scrollHeight
    }, 800);
    Send(uMsg);
    $("#txtMsg").val('');
}
}
$(window).on('keydown', function (e) {
    if (e.which == 13) {
        createPrompt();
        return false;
    }
});
//New UI controls
$(function () {
    $('[data-toggle="tooltip"]').tooltip();
});
//Text area resize
var textarea = document.getElementById("txtMsg");
var limit = 200;

textarea.oninput = function () {
    textarea.style.height = "";
    textarea.style.height = Math.min(textarea.scrollHeight, 300) + "px";
};